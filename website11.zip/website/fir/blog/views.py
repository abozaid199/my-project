# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.core.files.storage import FileSystemStorage
from django.shortcuts import render
from django.http import HttpResponse
from .models import createuser
from django.conf import settings

from django.contrib.auth import login, authenticate
from django.contrib.auth.forms import UserCreationForm
from django.shortcuts import render, redirect
from .form import SignUpForm
from django.views import generic
from django.views.generic import View
from django.template import loader

#from django.template import RequestContext
#from blog.models import *

#from django.contrib.auth.decorators import login_required
#from django.views.decorators.csrf import csrf_protect

from django.contrib.auth import logout
#from django.shortcuts import render_to_response,redirect

# Create your views here.

def logout_view(request):

    logout(request)
    model=createuser




    return render(request,'logout.html')




def home(request):
    return render(request,'home.html',{})


def signup(request):
    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            raw_password = form.cleaned_data.get('password1')
            user = authenticate(username=username, password=raw_password)
            login(request, user)
            return redirect('home')

    else:
        form = SignUpForm()
    return render(request, 'signup.html', {'form': form})




def login_user(request):
    logout(request)
    username = password = ''
    if request.POST:
        username = request.POST['username']
        password = request.POST['password']

        user = authenticate(username=username, password=password)
        if user is not None:
            if user.is_active:
                login(request, user)
                return render(request,'welcome.html',{'name':username})
                #return HttpResponseRedirect('/main/')
    return render(request,'login.html')


def index(request):

    cr=createuser.objects.all()

    template=loader.get_template('index.html')
    context={'cr':cr,}
    return HttpResponse(template.render(context, request))
    #return render(request,'index.html',context)




'''
    for users in cr:
        url='/admin/blog/createuser/'+str(users.id)+'/'

        html+='<a href="' + url + '" >' +users.first_name+' </a></br>'
        '''


'''
class userview(View):
    uform=userform
    tempn='reg.html'

    def get(self,request):
        form=self.uform(None)
        return render(request,self.tempn,{'form':form})

    def post(self,request):
        form=self.uform(request.POST)

        if form.is_valid():
            user=form.save(commit=False)

            username=form.cleaned_data['username']
            password=form.cleaned_data['password']
            user.set_password(password)
            user.save()


            user=authenticate(username=username,password=password)
            if user is not None:
                if user.is_active:
                    login(request,user)
                    return redirect('index')








def detail(request,user_id):
    return HttpResponse('<h1>details for user id :' +str(user_id)+'</h1>')

'''


























